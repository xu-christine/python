from py2neo import Node, Subgraph
from py2neo import Relationship
from py2neo import Graph


def main():
    graph = Graph("http://localhost:7474", auth=("neo4j", "xu0325"))

    graph.delete_all()
    node_0 = Node("root", name="linux")
    node_1 = Node("leader", name="cat")
    node_2 = Node("framer", name="system_call")
    node_3 = Node("file_caller", name="file_system")
    node_33 = Node("user", name="usage")

    node_4 = Node("function", name="usage()")
    node_5 = Node("function", name="emit_try_help")
    node_6 = Node("function", name="fputs")
    node_7 = Node("function", name="emit_stdin_note")

    node_8 = Node("function", name="next_line_num():")

    node_9 = Node("function", name="simple_cat():")
    node_10 = Node("function", name="safe_read")
    node_11 = Node("function", name="full_write")

    node_12 = Node("function", name="write_pending():")

    node_13 = Node("function", name="cat():")
    node_14 = Node("function", name="memmove")
    node_15 = Node("function", name="copy_cat():")
    node_16 = Node("function", name="copy_file_range")

    node_17 = Node("function", name="main():")
    node_18 = Node("function", name="initialize_main ")
    node_19 = Node("function", name="set_program_name")
    node_20 = Node("function", name="setlocale")
    node_21 = Node("function", name="bindtextdomain")
    node_22 = Node("function", name="textdomain")
    node_23 = Node("function", name="atexit")
    node_24 = Node("function", name="fstat")
    node_25 = Node("function", name="S_ISREG")
    node_26 = Node("function", name="fdadvise")
    node_27 = Node("function", name="lseek")
    node_28 = Node("function", name="xalignalloc")
    node_29 = Node("function", name="alignfree")
    node_30 = Node("function", name="close")

    node_31 = Node("function", name="open")
    node_32 = Node("function", name="read")

    node_34 = Node("usage", name="将文件内容打印到标准输出")
    node_35 = Node("usage", name="连接几个文件到目标文件")
    node_36 = Node("usage", name="添加几个文件到目标文件")
    node_37 = Node("usage", name="对所有输出行编号")
    node_38 = Node("usage", name="显示非打印字符和空白字符(如果不是ascii，则以M为前缀)")

    node_39 = Node("function", name="cat file")
    node_40 = Node("function", name="cat file1 file2 > target_file")
    node_41 = Node("function", name="cat file1 file2 >> target_file")
    node_42 = Node("function", name="cat -n file")
    node_43 = Node("function", name="cat -v -t -e file")

    rela1 = Relationship(node_0, "contain", node_1)
    rela2 = Relationship(node_1, "contain", node_2)
    rela3 = Relationship(node_1, "call", node_3)
    rela34 = Relationship(node_1, "use" , node_33)

    rela4 = Relationship(node_2, "call", node_4)
    rela5 = Relationship(node_2, "call", node_8)
    rela6 = Relationship(node_2, "call", node_9)
    rela7 = Relationship(node_2, "call", node_13)
    rela8 = Relationship(node_2, "call", node_17)

    rela9 = Relationship(node_4, "call", node_5)
    rela10 = Relationship(node_4, "call", node_6)
    rela11 = Relationship(node_4, "call", node_7)

    rela12 = Relationship(node_9, "call", node_10)
    rela13 = Relationship(node_9, "call", node_11)

    rela14 = Relationship(node_13, "call", node_14)
    rela15 = Relationship(node_13, "call", node_15)
    rela16 = Relationship(node_13, "call", node_16)

    rela17 = Relationship(node_17, "call", node_18)
    rela18 = Relationship(node_17, "call", node_19)
    rela19 = Relationship(node_17, "call", node_20)
    rela20 = Relationship(node_17, "call", node_21)
    rela21 = Relationship(node_17, "call", node_22)
    rela22 = Relationship(node_17, "call", node_23)
    rela23 = Relationship(node_17, "call", node_24)
    rela24 = Relationship(node_17, "call", node_25)
    rela25 = Relationship(node_17, "call", node_26)
    rela26 = Relationship(node_17, "call", node_27)
    rela27 = Relationship(node_17, "call", node_28)
    rela28 = Relationship(node_17, "call", node_29)
    rela29 = Relationship(node_17, "call", node_30)

    rela30 = Relationship(node_3, "call", node_31)
    rela31 = Relationship(node_3, "call", node_32)
    rela32 = Relationship(node_3, "call", node_30)
    rela33 = Relationship(node_2, "call", node_12)

    rela35 = Relationship(node_33, "use", node_34)
    rela36 = Relationship(node_33, "use", node_35)
    rela37 = Relationship(node_33, "use", node_36)
    rela38 = Relationship(node_33, "use", node_37)
    rela39 = Relationship(node_33, "use", node_38)
    rela40 = Relationship(node_34, "output", node_39)
    rela41 = Relationship(node_35, "output", node_40)
    rela42 = Relationship(node_36, "output", node_41)
    rela43 = Relationship(node_37, "output", node_42)
    rela44 = Relationship(node_38, "output", node_43)

    node_ls = [node_0, node_1, node_2, node_3, node_4, node_5, node_7, node_8, node_9,
               node_10, node_11, node_12, node_13, node_14, node_15, node_16, node_17,
               node_18, node_19, node_20, node_21, node_22, node_23, node_24, node_25,
               node_26, node_27, node_28, node_29, node_30, node_31, node_32, node_33,
               node_34, node_35, node_36, node_37, node_38, node_39, node_40, node_41,
               node_42, node_43]
    relation_ls = [rela1, rela2, rela3, rela4, rela5, rela6, rela7, rela8, rela9,
                   rela10, rela11, rela12, rela13, rela14, rela15, rela16, rela17,
                   rela18, rela19, rela20, rela21, rela22, rela23, rela24, rela25,
                   rela26, rela27, rela28, rela29, rela30, rela31, rela32, rela33,
                   rela34, rela35, rela36, rela37, rela38, rela39, rela40, rela41,
                   rela42, rela43, rela44]
    subgraph = Subgraph(node_ls, relation_ls)
    tr = graph.begin()
    tr.create(subgraph)
    graph.commit(tr)


if __name__ == '__main__':
    main()

