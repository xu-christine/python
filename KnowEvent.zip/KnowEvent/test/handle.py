#! /usr/bin/python

import sys
import os
dir_path = r"E:\XuPro\KnowEvent\data\tst"

# @brief search function name
# @note this function search backward from "(".
#       first we search isalnum, next we have been push at ret variable while all_text[i] == isalnum.
# @ret function name


def search_function_name(all_text, text_num):
    ret = ""
    push_status = False
    for i in range(text_num - 1, 0, -1):
        if push_status:
            # end of function name
            if all_text[i].isalnum() == False and all_text[i] != "_":
                return ret
            else:
                ret = all_text[i] + ret

        # search start pos
        else:
            if all_text[i].isalnum() or all_text[i] == "_":
                ret = all_text[i]
                push_status = True

    # it's Bug...
    raise Exception()


# @brief search ; or {.
# @note if find ;, this is callee. if find {, this is function declaration.
# @ret 1 find ; (callee).
# @ret 2 find { (function).
def search_end_code(all_text, text_num):
    for i in range(text_num, len(all_text)):
        if all_text[i] == ";":
            return 1
        if all_text[i] == "{":
            return 2

    # it's Bug...
    raise Exception()


# @brief search end of function.
# @note we search { and } block.
def search_end_function(all_text, text_num):
    depth = 1
    find_first_term = False
    for i in range(text_num, len(all_text)):
        if all_text[i] == "{":
            if find_first_term:
                depth += 1
            else:
                # if you already find {, it's maybe if or for statement blocks.
                find_first_term = True

        if all_text[i] == "}":
            if find_first_term:
                if depth == 1:
                    return i
                else:
                    depth -= 1
            else:
                # it's Bug...
                raise Exception()


def count_num_of_function_lines(all_text, begin_num, end_num):
    count = 0
    for i in range(begin_num, end_num):
        if all_text[i] == "\n":
            count += 1
    return count - 1


item_list = []  # [file_name, [function_callee_list]]
function_list = []


def analyze(file_list):
    # analyze C language files.
    path = dir_path
    for file in file_list:
        input_file_text_list = []
        input_file_all_text = ""
        function_hint = []

        try:
            f = open(path + "/" + file, "r")
        except IOError:
            print("Can't open " + file)
            continue

        # gather all line and make function hint
        line_num = 1
        for line in f:
            # search function hint
            try:
                i = line.index("(")
            except ValueError:
                i = None
            else:
                function_hint.append(
                    # save (number of line, index of line, position of all text) tuple
                    (line_num, i, i + len(input_file_all_text))
                )

            input_file_all_text += line
            input_file_text_list.append(line)
            line_num = line_num + 1

        # search function declaration
        temp_function_list = []  # [name, text_num, end_function_num, line_num, file_name]
        temp_callee_list = []  # [name, text_num, line_num, file_name]

        for hint in function_hint:
            hint_line_num = hint[0]
            hint_line_text_num = hint[1]
            hint_text_num = hint[2]

            name = search_function_name(input_file_all_text, hint_text_num)
            type = search_end_code(input_file_all_text, hint_text_num)

            if name == "if" or name == "for" or name == "switch" or name == "while":
                continue

            if (type == 1):
                temp_callee_list.append([name, hint_text_num, hint_line_num, file])
            #			print "callee : " + name + " at " + str(hint_text_num)
            elif (type == 2):
                end_function_num = search_end_function(input_file_all_text, hint_text_num)
                num_of_function_lines = count_num_of_function_lines(input_file_all_text, hint_text_num,
                                                                    end_function_num)

                is_not_function = False
                # if we find same end_function_num item, maybe before find item is invalid.
                for i in range(len(temp_function_list)):
                    if end_function_num == temp_function_list[i][2]:
                        # find same end_function_num
                        temp_function_list.pop(i)
                        break

                    if end_function_num < temp_function_list[i][2]:
                        # if this is inner function block, maybe this is invalid.
                        is_not_function = True
                        break

                if is_not_function:
                    continue

                temp_function_list.append([name, hint_text_num, end_function_num, hint_line_num,
                                           file, num_of_function_lines])

        # callee eliminate not inner function block.

        # build item tree.
        # item_list = [file_name, [function_callee_list]]
        # function_callee_list = [function_name , [callee_name, text_num, line_num, file_name]

        temp_item_list = [file, []]  # [file_name, [function_callee_list]]
        for function in temp_function_list:
            function_name = function[0]
            function_begin_num = function[1]
            function_end_num = function[2]

            # [function_name , [callee_name, text_num, line_num, file_name]
            function_callee_list = [function_name, []]
            for callee in temp_callee_list:
                callee_name = callee[0]
                callee_num = callee[1]

                # print "function : " + function[0] + " at " + str(function_begin_num) + " - " + str(function_end_num)
                # print "callee : " + callee_name + " at " + str(callee_num)

                if function_begin_num < callee_num < function_end_num:
                    callee.append(function_name)
                    function_callee_list[1].append(callee)

            temp_item_list[1].append(function_callee_list)

        function_list.extend(temp_function_list)
        item_list.append(temp_item_list)
        for ch in function_list:
            print(ch)
        print(item_list)


if __name__ == '__main__':
    files = os.listdir(dir_path)
    analyze(files)

