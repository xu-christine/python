import os


def main(node_name):
    # 中文node查询并返回该节点
    # cache = []
    # str_1 = "_.name=#"
    # flag = node[-1]
    # str_2 = str_1.replace("#", node)
    # cache.extend(str_2)
    # for i in range(len(cache)):
    #     if cache[i] == '=':
    #         cache.insert(i + 1, "'")
    # cache.append("'")
    # str_3 = ""
    # for ch in cache:
    #     str_3 += ch

    # 英文node查询并返回该节点
    cache = []
    str_1 = "_.name=#"
    str_2 = str_1.replace("#", node)
    cache.extend(str_2)
    for i in range(len(cache)):
        if cache[i] == '=':
            cache.insert(i + 1, "'")
    cache.append("'")
    str_3 = ""
    for ch in cache:
        str_3 += ch
    print(str_3)


if __name__ == '__main__':
    node = 'cat'
    main(node)
