# 对于源码进行处理
import os


dir_path = r"E:\XuPro\KnowEvent\data\extraction"


# 获取底层main所有调用函数名
def search_function(text, index):
    res = ""
    find_status = False
    for i in range(index - 1, 0, -1):
        if find_status:
            if text[i].isalnum() == False and text[i] != "_":
                return res
            else:
                res = text[i] + res
        else:
            if text[i].isalnum() or text[i] == "_":
                res = text[i]
                find_status = True
    # 否则报错
    raise Exception()


# 获取位置
def search_end(text, index):
    for i in range(index, len(text)):
        if text[i] == ";":
            return 1
        if text[i] == "{":
            return 2
    # 否则报错
    raise Exception()


# 获取调用深度,找到{block}中的内容
def search_deep(text, index):
    depth = 1
    find_front = False
    for i in range(index, len(text)):
        if text[i] == "{":
            if find_front:
                depth += 1
            else:
                find_front = True
        if text[i] == "}":
            if find_front:
                if depth == 1:
                    return i
                else:
                    depth -= 1
            else:
                raise Exception()


# 位置
def count_function_line(text, begin_idx, end_idx):
    count = 0
    for i in range(begin_idx, end_idx):
        if text[i] == "\n":
            count += 1
    return count - 1


# [filename, [[caller,[[callee,]]]]
item_list = []
# [function,  ]
function_list = []


# 遍历文件集合中的所有文件并处理
def traverse(file_list):
    path = dir_path
    for file in file_list:
        text_list = []
        all_text = ""
        function_ch = []
        body = ""
        try:
            body = open(path + "/" + file, "r")
        except IOError:
            print("Can't open " + file)
            continue

        # gather all line and make function hint
        line_num = 1
        for line in body:
            # search function hint
            try:
                i = line.index("(")
            except ValueError:
                i = None
            else:
                # save (number of line, index of line, position of all text) tuple
                function_ch.append((line_num, i, i + len(all_text)))

            all_text += line
            text_list.append(line)
            line_num = line_num + 1

        # search function declaration
        temp_function_list = []  # [name, text_num, end_function_idx, line_num, file_name]
        temp_callee_list = []  # [name, text_num, line_num, file_name]

        for ch in function_ch:
            ch_line_num = ch[0]
            ch_line_text_num = ch[1]
            ch_text_num = ch[2]

            name = search_function(all_text, ch_text_num)
            func_type = search_end(all_text, ch_text_num)

            if name == "if" or name == "for" or name == "switch" or name == "while":
                continue

            if func_type == 1:
                temp_callee_list.append([name, ch_text_num, ch_line_num, file])
            elif func_type == 2:
                end_function_num = search_deep(all_text, ch_text_num)
                num_function_line = count_function_line(all_text, ch_text_num, end_function_num)

                is_not_function = False
                # if we find same end_function_num item, maybe before find item is invalid.
                for i in range(len(temp_function_list)):
                    if end_function_num == temp_function_list[i][2]:
                        # find same end_function_num
                        temp_function_list.pop(i)
                        break

                    if end_function_num < temp_function_list[i][2]:
                        # if this is inner function block, maybe this is invalid.
                        is_not_function = True
                        break

                if is_not_function:
                    continue

                temp_function_list.append([name, ch_text_num, end_function_num, ch_line_num,
                                           file, num_function_line])

        # callee eliminate not inner function block.
        # build item tree.
        # item_list = [file_name, [function_callee_list]]
        # function_callee_list = [function_name , [callee_name, text_num, line_num, file_name]

        temp_item_list = [file, []]  # [file_name, [function_callee_list]]
        for function in temp_function_list:
            function_name = function[0]
            function_begin_idx = function[1]
            function_end_idx = function[2]

            # [function_name , [callee_name, text_num, line_num, file_name]
            function_callee_list = [function_name, []]
            for callee in temp_callee_list:
                callee_name = callee[0]
                callee_num = callee[1]

                # print "function : " + function[0] + " at " + str(function_begin_num) + " - " + str(function_end_num)
                # print "callee : " + callee_name + " at " + str(callee_num)

                if function_begin_idx < callee_num < function_end_idx:
                    callee.append(function_name)
                    function_callee_list[1].append(callee)

            temp_item_list[1].append(function_callee_list)

        function_list.extend(temp_function_list)
        item_list.append(temp_item_list)

    # print(function_list)
    # print(item_list)
    # print(temp_function_list)
    m_func_trip = composite(function_list)
    s_func_trip = formate(item_list)
    func_dict = {'m_func_trip': m_func_trip, 's_func_trip': s_func_trip}
    return func_dict


def composite(list1):
    p_list = list1
    rela = 'call'
    triple = []
    for function in p_list:
        func = function[0]
        file = function[4]
        m_func = file.replace(".c", "")
        triple.append([file, m_func, func, rela])
    # print(triple)
    return triple


def formate(list1):
    p_list = list1
    rela = 'call'
    t_1 = []
    triple = []
    scr_set = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
               'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
               'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
               'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
               '_', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
    for file in p_list:
        for i in range(len(file)):
            if i % 2 == 1:
                t_1.append(file[i])
            else:
                continue
    t_2 = sum(t_1, [])
    t_3 = sum(t_2, [])
    t_4 = []
    for i in range(len(t_3)):
        if t_3[i] != [] and i % 2 == 1:
            t_4.append(t_3[i])
        else:
            continue
    t_5 = sum(t_4, [])
    # print(t_5)

    for items in t_5:
        stat_ss = []
        ss_func = items[0]
        file = items[3]
        func = file.replace(".c", "")
        s_func = items[4]
        stat_ss.append(ss_func)
        flag = inter(stat_ss, scr_set)
        if flag:
            continue
        else:
            triple.append([file, func, s_func, ss_func, rela])
            stat_ss.clear()
    t_triple = []
    for each in triple:
        if each not in t_triple:
            t_triple.append(each)
    # print(triple)
    # print(t_triple)
    return t_triple


def inter(a, b):
    return list(set(a) & set(b))


# 主函数--控制流程
if __name__ == '__main__':
    files = os.listdir(dir_path)
    all_list = traverse(files)
    print(all_list)
