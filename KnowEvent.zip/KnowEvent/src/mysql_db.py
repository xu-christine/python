#!/usr/bin/python3.10
# -*- coding:utf-8 -*-
import re
import pymysql
import time
import random

db = pymysql.connect(host='localhost', user='root', passwd='xu0325', db='myth_db', charset="utf8", autocommit=True)
cur = db.cursor()  # 创建并返回游标


def table_exists(con, table_name):  # 这个函数用来判断表是否存在
    sql = "show tables;"
    con.execute(sql)
    tables = [con.fetchall()]
    table_list = re.findall('(\'.*?\')', str(tables))
    table_list = [re.sub("'", '', each) for each in table_list]
    if table_name in table_list:
        return 1  # 存在返回1
    else:
        return 0


# 创建类别表
sql_tb1 = """CREATE TABLE class_tb(
                 `cl_classify` VARCHAR(50)  NOT NULL,
                 `order` CHAR(20) NOT NULL,
                 `rela` CHAR(20),
                 PRIMARY KEY(`cl_classify`,`order`))
                 """
# 创建命令表
sql_tb2 = """CREATE TABLE order_tb(
                 `order_file` VARCHAR(50)  NOT NULL,
                 `order` CHAR(20)  NOT NULL,
                 `s_func` CHAR(20) NOT NULL,
                 `rela` CHAR(20),
                 PRIMARY KEY(`order`,`s_func`))
                 """
# 创建函数表
sql_tb3 = """CREATE TABLE s_func_tb(
                 `s_func_file` VARCHAR(50)  NOT NULL,
                 `s_order` CHAR(20)  NOT NULL,
                 `s_func` CHAR(20)  NOT NULL,
                 `ss_func` CHAR(30) NOT NULL,
                 `rela` CHAR(20),
                 PRIMARY KEY(`s_func`,`ss_func`))
                 """
# 创建用法表
sql_tb4 = """CREATE TABLE use_tb (
                 `order`  CHAR(20)  NOT NULL,
                 `use_way` VARCHAR(100) NOT NULL,
                 `rela` CHAR(20),
                 PRIMARY KEY(`order`,`use_way`))
                 """
# 创建文件系统分析表
sql_tb5 = """CREATE TABLE file_sys_tb (
                 `order`  CHAR(20)  NOT NULL,
                 `affair` VARCHAR(100) NOT NULL,
                 `rela` CHAR(20),
                 PRIMARY KEY(`order`,`affair`))
                 """
# 创建关联表
sql_tb6 = """CREATE TABLE corr_tb (
                 `order`  CHAR(20)  NOT NULL,
                 `corr_order` VARCHAR(100) NOT NULL,
                 `rela` CHAR(20),
                 PRIMARY KEY(`order`,`corr_order`))
                 """


# 类别表的插入 classify--order
def class_insert(class_list):
    t_list = class_list
    for item in t_list:
        sql = "insert ignore into class_tb(`cl_classify`, `order`, `rela`) values(%s,%s,%s)"
        cl_classify = item[0]
        order = item[1]
        rela = 'contain'
        try:
            cur.execute(sql, (cl_classify, order, rela))
            db.commit()
            print("success")
        except BaseException as e:
            print(e)
            db.rollback()
    db.close()
    cur.close()


# 命令表的插入 order--s_func
def order_insert(order_list):
    t_list = order_list
    for item in t_list:
        sql = "insert ignore into order_tb(`order_file`, `order`,`s_func`, `rela`) values(%s,%s,%s,%s)"
        order_file = item[0]
        order = item[1]
        s_func = item[2]
        rela = item[3]
        try:
            cur.execute(sql, (order_file, order, s_func, rela))
            db.commit()
            print("success")
        except BaseException as e:
            print(e)
            db.rollback()
    db.close()
    cur.close()


# 函数表的插入 s_func--ss_func
def s_func_insert(s_func_list):
    t_list = s_func_list
    for item in t_list:
        sql = "insert ignore into s_func_tb(`s_func_file`, `s_order`,`s_func`,`ss_func`, `rela`) values(%s,%s,%s,%s,%s)"
        s_func_file = item[0]
        s_order = item[1]
        s_func = item[2]
        ss_func = item[3]
        rela = item[4]
        try:
            cur.execute(sql, (s_func_file, s_order, s_func, ss_func, rela))
            db.commit()
            print("success")
        except BaseException as e:
            print(e)
            db.rollback()
    db.close()
    cur.close()


# 用法表的插入 order--usage
def use_insert(use_list):
    t_list = use_list
    for item in t_list:
        sql = "insert ignore into use_tb(`order`, `use_way`, `rela`) values(%s,%s,%s)"
        order = item[0]
        use_way = item[1]
        rela = 'use'
        try:
            cur.execute(sql, (order, use_way, rela))
            db.commit()
            print("success")
        except BaseException as e:
            print(e)
            db.rollback()
    db.close()
    cur.close()


# 文件系统分析表表的插入 order--filesystem
def file_sys_insert(use_list):
    t_list = use_list
    for item in t_list:
        sql = "insert ignore into file_sys_tb(`order`, `affair`, `rela`) values(%s,%s,%s)"
        order = item[0]
        affair = item[1]
        rela = 'practice'
        try:
            cur.execute(sql, (order, affair, rela))
            db.commit()
            print("success")
        except BaseException as e:
            print(e)
            db.rollback()
    db.close()
    cur.close()


# 表的插入 order--corr_order
def corr_insert(use_list):
    t_list = use_list
    for item in t_list:
        sql = "insert ignore into corr_tb(`order`, `corr_order`, `rela`) values(%s,%s,%s)"
        order = item[0]
        corr_order = item[1]
        rela = 'associate'
        try:
            cur.execute(sql, (order, corr_order, rela))
            db.commit()
            print("success")
        except BaseException as e:
            print(e)
            db.rollback()
    db.close()
    cur.close()


def main():
    # 判断分类列表是否创建
    if table_exists(cur, 'class_tb') != 1:
        print("class_tb,不存在,已创建！")
        cur.execute(sql_tb1)
        db.commit()
    else:
        print("class_tb,已存在！")

    # 判断命令表是否创建
    if table_exists(cur, 'order_tb') != 1:
        print("order_tb,不存在,已创建！")
        cur.execute(sql_tb2)
        db.commit()
    else:
        print("order_tb,已存在！")

    # 判断函数表是否创建
    if table_exists(cur, 's_func_tb') != 1:
        print("s_func_tb,不存在,已创建！")
        cur.execute(sql_tb3)
        db.commit()
    else:
        print("s_func_tb,已存在！")

    # 判断用法表是否创建
    if table_exists(cur, 'use_tb') != 1:
        print("use_tb,不存在,已创建！")
        cur.execute(sql_tb4)
        db.commit()
    else:
        print("use_tb,已存在！")

    # 判断文件系统分析表是否创建
    if table_exists(cur, 'file_sys_tb') != 1:
        print("file_sys_tb,不存在,已创建！")
        cur.execute(sql_tb5)
        db.commit()
    else:
        print("file_sys_tb,已存在！")

    # 判断关联表是否创建
    if table_exists(cur, 'corr_tb') != 1:
        print("corr_tb,不存在,已创建！")
        cur.execute(sql_tb6)
        db.commit()
    else:
        print("corr_tb,已存在！")
    db.close()
    cur.close()


if __name__ == '__main__':
    main()
