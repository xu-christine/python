# 连接neo4j数据库,构建知识图谱
import csv
from py2neo import Graph, Node, Relationship, NodeMatcher

graph = Graph("http://localhost:7474", auth=("neo4j", "xu0325"))
# graph.delete_all()  # 清除neo4j中原有的结点等所有信息


# "_.name='cat'"
# 针对节点(已存在)存在查询，返回该节点
def C_nodeExist(label, node):
    matcher = NodeMatcher(graph)
    cache = []
    str_1 = "_.name=#"
    str_2 = str_1.replace("#", node)
    cache.extend(str_2)
    for i in range(len(cache)):
        if cache[i] == '=':
            cache.insert(i + 1, "'")
    cache.append("'")
    str_3 = ""
    for ch in cache:
        str_3 += ch
    create_node = matcher.match(label).where(str_3).first()
    if create_node is None:
        return False
    else:
        return create_node


def t_class():
    with open(r'E:\XuPro\KnowEvent\data\class_tb.csv', 'r', encoding='utf8') as f:
        reader = csv.reader(f)
        data = list(reader)
        root = Node('root', name='Linux')
        graph.create(root)
        for i in range(len(data)):
            if i == 0:
                continue
            else:
                if not C_nodeExist('classify', data[i][0]):
                    first = Node('classify', name=data[i][0])
                    r_f_rela = Relationship(root, 'contain', first)
                    graph.create(first)
                    graph.create(r_f_rela)
                    if not C_nodeExist('order', data[i][1]):
                        second1 = Node('order', name=data[i][1])
                        graph.create(second1)
                        f_s_rela1 = Relationship(first, data[i][2], second1)
                        graph.create(f_s_rela1)
                    else:
                        second1 = C_nodeExist(data[i][1])
                        f_s_rela1 = Relationship(first, data[i][2], second1)
                        graph.create(f_s_rela1)
                else:
                    first = C_nodeExist('classify', data[i][0])
                    r_f_rela = Relationship(root, 'contain', first)
                    graph.create(r_f_rela)
                    if not C_nodeExist('order', data[i][1]):
                        second2 = Node('order', name=data[i][1])
                        graph.create(second2)
                        f_s_rela2 = Relationship(first, data[i][2], second2)
                        graph.create(f_s_rela2)
                    else:
                        second2 = C_nodeExist('order', data[i][1])
                        f_s_rela2 = Relationship(first, data[i][2], second2)
                        graph.create(f_s_rela2)


def t_order():
    with open(r'E:\XuPro\KnowEvent\data\order_tb.csv', 'r', encoding='utf8') as f:
        reader = csv.reader(f)
        data = list(reader)
        for i in range(len(data)):
            if i == 0:
                continue
            else:
                if not C_nodeExist('order', data[i][0]):
                    first = Node('order', name=data[i][0])
                    graph.create(first)
                    if not C_nodeExist('s_func', data[i][1]):
                        second1 = Node('s_func', name=data[i][1])
                        graph.create(second1)
                        f_s_rela1 = Relationship(first, data[i][2], second1)
                        graph.create(f_s_rela1)
                    else:
                        second1 = C_nodeExist('s_func', data[i][1])
                        f_s_rela1 = Relationship(first, data[i][2], second1)
                        graph.create(f_s_rela1)
                else:
                    first = C_nodeExist('order', data[i][0])
                    if not C_nodeExist('s_func', data[i][1]):
                        second2 = Node('s_func', name=data[i][1])
                        graph.create(second2)
                        f_s_rela2 = Relationship(first, data[i][2], second2)
                        graph.create(f_s_rela2)
                    else:
                        second2 = C_nodeExist('s_func', data[i][1])
                        f_s_rela2 = Relationship(first, data[i][2], second2)
                        graph.create(f_s_rela2)


def t_func():
    with open(r'E:\XuPro\KnowEvent\data\s_func_tb.csv', 'r', encoding='utf8') as f:
        reader = csv.reader(f)
        data = list(reader)
        for i in range(len(data)):
            if i == 0:
                continue
            else:
                if not C_nodeExist('s_func', data[i][0]):
                    first = Node('s_func', name=data[i][0])
                    graph.create(first)
                    if not C_nodeExist('ss_func', data[i][1]):
                        second1 = Node('ss_func', name=data[i][1])
                        graph.create(second1)
                        f_s_rela1 = Relationship(first, data[i][2], second1)
                        graph.create(f_s_rela1)
                    else:
                        second1 = C_nodeExist('ss_func', data[i][1])
                        f_s_rela1 = Relationship(first, data[i][2], second1)
                        graph.create(f_s_rela1)
                else:
                    first = C_nodeExist('s_func', data[i][0])
                    if not C_nodeExist('ss_func', data[i][1]):
                        second2 = Node('ss_func', name=data[i][1])
                        graph.create(second2)
                        f_s_rela2 = Relationship(first, data[i][2], second2)
                        graph.create(f_s_rela2)
                    else:
                        second2 = C_nodeExist('ss_func', data[i][1])
                        f_s_rela2 = Relationship(first, data[i][2], second2)
                        graph.create(f_s_rela2)


def t_use():
    with open(r'E:\XuPro\KnowEvent\data\use_tb.csv', 'r', encoding='utf8') as f:
        reader = csv.reader(f)
        data = list(reader)
        for i in range(len(data)):
            if i == 0:
                continue
            else:
                order = C_nodeExist('order', data[i][0])
                if not C_nodeExist('usage', data[i][0] + '-' + 'usage'):
                    o_usage = Node('usage', name=(data[i][0] + '-' + 'usage'))
                    graph.create(o_usage)
                    o_u_rela = Relationship(order, "offer", o_usage)
                    graph.create(o_u_rela)

                    first = Node('use_way', name=data[i][1])
                    graph.create(first)
                    u_s_rela1 = Relationship(o_usage, data[i][2], first)
                    graph.create(u_s_rela1)
                else:
                    o_usage = C_nodeExist('usage', (data[i][0] + '-' + 'usage'))

                    first = Node('use_way', name=data[i][1])
                    graph.create(first)
                    u_s_rela1 = Relationship(o_usage, data[i][2], first)
                    graph.create(u_s_rela1)


def t_f_sys():
    with open(r'E:\XuPro\KnowEvent\data\file_sys_tb.csv', 'r', encoding='utf8') as f:
        reader = csv.reader(f)
        data = list(reader)
        for i in range(len(data)):
            if i == 0:
                continue
            else:
                if not C_nodeExist('order', data[i][0]):
                    first = Node('order', name=data[i][0])
                    graph.create(first)
                    if not C_nodeExist('filesystem', data[i][0] + '-' + 'filesystem'):
                        o_f_sys = Node('filesystem', name=(data[i][0] + '-' + 'filesystem'))
                        graph.create(o_f_sys)
                        o_f_rela = Relationship(first, "effect", o_f_sys)
                        graph.create(o_f_rela)

                        first = Node('affair', name=data[i][1])
                        graph.create(first)
                        u_s_rela1 = Relationship(o_f_sys, data[i][2], first)
                        graph.create(u_s_rela1)
                    else:
                        f_sys = C_nodeExist('filesystem', (data[i][0] + '-' + 'filesystem'))

                        first = Node('affair', name=data[i][1])
                        graph.create(first)
                        u_s_rela1 = Relationship(f_sys, data[i][2], first)
                        graph.create(u_s_rela1)
                else:
                    order = C_nodeExist('order', data[i][0])
                    if not C_nodeExist('filesystem', data[i][0] + '-' + 'filesystem'):
                        o_f_sys = Node('filesystem', name=(data[i][0] + '-' + 'filesystem'))
                        graph.create(o_f_sys)
                        o_f_rela = Relationship(order, "effect", o_f_sys)
                        graph.create(o_f_rela)

                        first = Node('affair', name=data[i][1])
                        graph.create(first)
                        u_s_rela1 = Relationship(o_f_sys, data[i][2], first)
                        graph.create(u_s_rela1)
                    else:
                        f_sys = C_nodeExist('filesystem', (data[i][0] + '-' + 'filesystem'))

                        first = Node('affair', name=data[i][1])
                        graph.create(first)
                        u_s_rela1 = Relationship(f_sys, data[i][2], first)
                        graph.create(u_s_rela1)


def t_corr():
    with open(r'E:\XuPro\KnowEvent\data\corr_tb.csv', 'r', encoding='utf8') as f:
        reader = csv.reader(f)
        data = list(reader)
        for i in range(len(data)):
            if i == 0:
                continue
            else:
                first = C_nodeExist('order', data[i][0])
                second = C_nodeExist('order', data[i][1])
                f_s_rela = Relationship(first, 'associate', second)
                graph.create(f_s_rela)


def main():
    t_class()
    t_order()
    t_func()
    t_use()
    t_f_sys()
    t_corr()


if __name__ == '__main__':
    main()
