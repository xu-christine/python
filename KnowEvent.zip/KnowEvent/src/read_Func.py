# 读取命令用法文件
# -*- coding:utf-8 -*-
import os
import re

func_path = r"E:\XuPro\KnowEvent\data\Function"
class_path = r"E:\XuPro\KnowEvent\data\classify"
file_sys_path = r"E:\XuPro\KnowEvent\data\Filesystem"
corr_path = r"E:\XuPro\KnowEvent\data\correlation"


# 读取文件内容
def extract(file):
    cache_1 = []
    if not os.path.isdir(file):
        try:
            with open(file, "r", encoding='utf-8') as file:
                body = file.read()
                for line in body:
                    cache_1 += line
        except IOError:
            print("Can't open" + file)
    return cache_1


# 获取指定值下标，截取内容
def pos(text):
    for i in range(len(text)):
        if text[i] == '@':
            break
    return i


# 获取函数体状态
def t_stat(ch):
    idx_pos = 0
    for i in range(len(ch)):
        if ch[i] == '{':
            return 1
        if ch[i] == '}':
            return 2
        if ch[i] == '：':
            return 3
        if ch[i] == '#':
            return 4
        if ch[i] == '\n':
            return 5


# 获取指定部分内容--function
def idx1_body(text, idx_st, idx_end):
    ch_tmp = text
    ch = ""
    st = idx_st
    end = idx_end
    for i in range(st, end):
        ch += ch_tmp[i]
    return ch


# 获取二维list数据表
def idx2_body(list1, list2):
    st = 0
    end = 0
    res_body = []
    for i in range(len(list1)):
        if end != list1[i]:
            end = list1[i]
            body = i_pos(list2, st, end)
            res_body.append(body)
            st = end
    # print(res_body)
    return res_body


# 获取指定部分的下标，对应的内容
def i_pos(list1, st, end):
    ch = []
    for i in range(st, end):
        ch.append(list1[i])
    return ch


# 对获取的数据进行处理
def parse(ls):
    body = ls

    tmp_t = []
    tmp_func = []
    tmp_ch = []
    len_num_ls = []
    idx = pos(body)
    for ch in body[idx + 2:]:
        tmp_t.append(ch)

    idx_st = 0
    for i in range(len(tmp_t)):

        if t_stat(tmp_t[i]) == 3:
            idx_end = i
            tmp_func.append(idx1_body(tmp_t, idx_st, idx_end))
            continue

        elif t_stat(tmp_t[i]) == 1:
            idx_st = i + 2

        elif t_stat(tmp_t[i]) == 2:
            idx_end = i
            tmp_ch += idx1_body(tmp_t, idx_st, idx_end)

            i_st = 0
            tmp_c = []
            for i1 in range(len(tmp_ch)):
                if t_stat(tmp_ch[i1]) == 4:
                    i_st = i1 + 1
                elif t_stat(tmp_ch[i1]) == 5:
                    i_end = i1
                    len_idx_st = 0
                    tmp_c.append(idx1_body(tmp_ch, i_st, i_end))
                else:
                    continue
            len_idx_end = len(tmp_c)
            len_num = len_idx_end - len_idx_st
            len_num_ls.append(len_num)
            len_idx_st = len_idx_end
            idx_st = i + 2

    res = idx2_body(len_num_ls, tmp_c)

    # print(triple)
    # print(tmp_func)
    # print(res)

    res_dict = {}
    res_list = []
    for i in range(len(tmp_func)):
        res_dict[tmp_func[i]] = res[i]
    for k, v in iter_trans(res_dict):
        res_list.append([k, v])
    return res_list


def iter_trans(t_dict):
    for k, values in t_dict.items():
        for v in values:
            yield k, v


# 主函数--控制流程
if __name__ == '__main__':
    # func函数提取
    func_1 = extract(func_path)
    func = parse(func_1)
    # print(func)

    # class提取
    cl_body = extract(class_path)
    cl = parse(cl_body)
    # print(cl)

    # file_system相关提取
    f_sys_body = extract(file_sys_path)
    f_sys = parse(f_sys_body)
    print(f_sys)

    # correlation相关提取
    corr_body = extract(corr_path)
    corr = parse(corr_body)
    print(corr)



