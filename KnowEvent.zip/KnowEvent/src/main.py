# python 3.10
# -*- coding:utf-8 -*-
# 主程序----控制流程
import os
dir_path = r"E:\XuPro\KnowEvent\data\extraction"

class_path = r"E:\XuPro\KnowEvent\data\classify"
func_path = r"E:\XuPro\KnowEvent\data\Function"
file_sys_path = r"E:\XuPro\KnowEvent\data\Filesystem"
corr_path = r"E:\XuPro\KnowEvent\data\correlation"


# 解析源码
def main_parse(file_list):
    from File_handle import traverse
    func_dict = traverse(file_list)
    func_list = func_dict['m_func_trip']
    item_list = func_dict['s_func_trip']
    triple = [func_list, item_list]
    return triple


# 读取Function_txt文件内容, 获得命令用法
def main_read():
    from read_Func import extract, parse
    # use相关提取
    func_1 = extract(func_path)
    func = parse(func_1)
    # print(func)

    # class提取
    cl_body = extract(class_path)
    cl = parse(cl_body)
    # print(cl)

    # file_system相关提取
    f_sys_body = extract(file_sys_path)
    f_sys = parse(f_sys_body)
    # print(f_sys)

    # correlation相关提取
    corr_body = extract(corr_path)
    corr = parse(corr_body)
    # print(corr)
    triple = [cl, func, f_sys, corr]
    return triple


# 对获取的数据进行存储到MySQL
def sql(triple):
    from mysql_db import order_insert, s_func_insert
    from mysql_db import class_insert, use_insert, file_sys_insert, corr_insert
    if triple[1] == 1:
        func_list = triple[0][0]
        item_list = triple[0][1]
        # order_insert(func_list)
        # s_func_insert(item_list)
    if triple[1] == 2:
        cl_list = triple[0][0]
        use_list = triple[0][1]
        f_sys_list = triple[0][2]
        corr = triple[0][3]
        # class_insert(cl_list)
        # use_insert(use_list)
        # file_sys_insert(f_sys_list)
        corr_insert(corr)


# 对于提取的数据批量放入neo4j,同时创建节点
def create_graph():
    from neo4j_graph import main
    # main()


def main():
    # 分析源码文件
    files_list = os.listdir(dir_path)
    code_triple = [main_parse(files_list), 1]
    # sql(code_triple)

    # 更改path读取文件内容[class_path,func_path,file_sys_path,corr_path]
    read_triple = [main_read(), 2]
    sql(read_triple)


# 主函数----控制流程
if __name__ == '__main__':
    main()
